<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <link rel="stylesheet" href="assets/css/style.css">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <title>News Carousel</title>

    <style>
        @media screen and (max-width: 992px) {
            .carousel-caption h1 {
                font-size: 1.7em !important;
            }

            .carousel-caption p {
                font-size: 1em !important;
            }
        }
    </style>

</head>

<body>

    <?php
    include 'slider_news.php';

    $slidesCount = count($newsRecords);

    // Indicators

    echo "<ol class='carousel-indicators'>";
    $indicators = "<li data-target='#carouselCaptions' data-slide-to='0' class='active'></li>";
    for ($i = 1; $i < $slidesCount; $i++) {
        $indicators .= "<li data-target='#carouselCaptions' data-slide-to='$i'></li>";
    }
    echo $indicators;
    echo "</ol>";
    echo "<div class='carousel-inner'>";

    // Slides

    $slides = "
    <div class='carousel-item active'>
        <img src='./assets/img/image0.jpg' class='d-block w-100' alt='Slide 1'>
        <div class='carousel-caption'>
            <h1><b>" . $newsRecords[0]['newsTitle'] . "</b></h1>
            <p style='font-size:1.5em;'>" . $newsRecords[0]['newsBody'] . "</p>
        </div>
    </div>";

    for ($count = 1; $count < $slidesCount; $count++) {
        $slides .= "
        <div class='carousel-item'>
            <img src='./assets/img/image$count.jpg' class='d-block w-100' alt='Slide $count'>
            <div class='carousel-caption'>
                <h1><b>" . $newsRecords[$count]['newsTitle'] . "</b></h1>
                <p style='font-size:1.5em;'>" . $newsRecords[$count]['newsBody'] . "</p>
            </div>
        </div>";
    }

    echo $slides;
    ?>

    </div>

    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.6/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>

</body>

</html>