-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Nov 10, 2023 at 12:00 AM
-- Server version: 10.4.27-MariaDB
-- PHP Version: 8.2.0

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `sms`
--

-- --------------------------------------------------------

--
-- Table structure for table `admins`
--

CREATE TABLE `admins` (
  `AdminID` int(11) NOT NULL,
  `Username` varchar(255) NOT NULL,
  `Password` varchar(255) NOT NULL,
  `FirstName` varchar(50) NOT NULL,
  `LastName` varchar(50) NOT NULL,
  `Email` varchar(255) NOT NULL,
  `CreatedAt` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `admins`
--

INSERT INTO `admins` (`AdminID`, `Username`, `Password`, `FirstName`, `LastName`, `Email`, `CreatedAt`) VALUES
(1, 'admin1', '1234', 'Kasun', 'Silva', 'kasun.silva@example.com', '2023-11-09 18:28:37'),
(2, 'admin2', '1234', 'Malini', 'Fernando', 'malini.fernando@example.com', '2023-11-09 18:28:37'),
(3, 'admin3', '1234', 'Sanjeewa', 'Perera', 'sanjeewa.perera@example.com', '2023-11-09 18:28:37');

-- --------------------------------------------------------

--
-- Table structure for table `coaches`
--

CREATE TABLE `coaches` (
  `CoachID` int(11) NOT NULL,
  `FirstName` varchar(50) DEFAULT NULL,
  `LastName` varchar(50) DEFAULT NULL,
  `DateOfBirth` date DEFAULT NULL,
  `Gender` varchar(20) DEFAULT NULL,
  `Email` varchar(100) DEFAULT NULL,
  `PhoneNumber` varchar(20) DEFAULT NULL,
  `Address` text DEFAULT NULL,
  `Specialty` varchar(100) DEFAULT NULL,
  `Certifications` text DEFAULT NULL,
  `SportID` int(11) DEFAULT NULL,
  `Password` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `coaches`
--

INSERT INTO `coaches` (`CoachID`, `FirstName`, `LastName`, `DateOfBirth`, `Gender`, `Email`, `PhoneNumber`, `Address`, `Specialty`, `Certifications`, `SportID`, `Password`) VALUES
(200, 'Rohan', 'Silva', '1980-05-15', 'Male', 'rohan.silva@emcscail.com', '909090', '10 Galle Road, Colombo, Sri Lanka', 'Cricket Coaching', 'Level 2 Coaching Certificate', 101, '1234'),
(201, 'Dilini', 'Fernando', '1975-06-20', 'Female', 'dilini.fernando@email.com', '777-201-2010', '22 Kandy Road, Kandy, Sri Lanka', 'Tennis Coaching', 'Tennis Pro Certification', 102, '1234');

-- --------------------------------------------------------

--
-- Table structure for table `coach_sports`
--

CREATE TABLE `coach_sports` (
  `CoachSportID` int(11) NOT NULL,
  `CoachID` int(11) NOT NULL,
  `SportID` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `coach_sports`
--

INSERT INTO `coach_sports` (`CoachSportID`, `CoachID`, `SportID`) VALUES
(1, 210, 102),
(2, 210, 103),
(3, 211, 103),
(4, 212, 102),
(5, 212, 103),
(6, 212, 104);

-- --------------------------------------------------------

--
-- Table structure for table `inventory`
--

CREATE TABLE `inventory` (
  `EquipmentID` int(11) NOT NULL,
  `EquipmentName` varchar(255) NOT NULL,
  `Quantity` int(11) NOT NULL,
  `Availability` enum('Available','Not Available') NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `inventory`
--

INSERT INTO `inventory` (`EquipmentID`, `EquipmentName`, `Quantity`, `Availability`) VALUES
(2, 'Knee Guards', 2523, 'Available'),
(3, 'Gloves', 35, 'Available'),
(4, 'Soccer Balls', 40, 'Available'),
(5, 'Shin Guards', 20, 'Not Available'),
(6, 'Basketballs', 30, 'Available'),
(7, 'Tennis Rackets', 15, 'Not Available'),
(8, 'Tennis Balls', 100, 'Available'),
(9, 'Badminton Rackets', 40, 'Available'),
(10, 'Badminton Shuttles', 200, 'Available'),
(12, 'Baseballs', 15, 'Available'),
(13, 'Swimming Goggles', 30, 'Available'),
(14, 'Swim Caps', 25, 'Not Available'),
(15, 'Dumbbells', 50, 'Available'),
(16, 'Yoga Mats', 40, 'Available'),
(17, 'Ping Pong Paddles', 20, 'Not Available'),
(18, 'Ping Pong Balls', 100, 'Available'),
(19, 'Volleyballs', 30, 'Available'),
(20, 'Gymnastics Mats', 15, 'Not Available'),
(21, 'Gymnastics Rings', 10, 'Available'),
(23, 'Cricket Bats', 25, 'Not Available'),
(24, 'Hockey Sticks', 30, 'Available'),
(26, 'Rugby Balls', 20, 'Not Available'),
(49, 'aa', 4, 'Available'),
(50, 'aa', 4, 'Available');

-- --------------------------------------------------------

--
-- Table structure for table `matches`
--

CREATE TABLE `matches` (
  `MatchID` int(11) NOT NULL,
  `SportID` int(11) DEFAULT NULL,
  `Date` date DEFAULT NULL,
  `Location` varchar(255) DEFAULT NULL,
  `Teams` varchar(255) DEFAULT NULL,
  `Winners` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `matches`
--

INSERT INTO `matches` (`MatchID`, `SportID`, `Date`, `Location`, `Teams`, `Winners`) VALUES
(1001, 101, '2023-10-25', 'University of Colombo', 'Team A vs. Team B', 'Team A'),
(1002, 102, '2023-10-26', 'University of Peradeniya', 'Team X vs. Team Y', 'Team Y'),
(1003, 103, '2023-10-27', 'University of Kelaniya', 'Team P vs. Team Q', ''),
(1004, 104, '2023-10-28', 'University of Moratuwa', 'Team M vs. Team N', 'Team N'),
(1005, 101, '2023-10-29', 'University of Sri Jayewardenepura', 'Team C vs. Team D', 'Team D'),
(1006, 101, '2023-10-04', 'Rajarata University', 'A vs B', ''),
(1007, 105, '2023-10-16', 'asadac', 'sada', ''),
(1008, 104, '2023-10-04', 'fdbf', 'svds', 'x');

-- --------------------------------------------------------

--
-- Table structure for table `news`
--

CREATE TABLE `news` (
  `id` int(11) NOT NULL,
  `important` tinyint(1) DEFAULT NULL,
  `newsTitle` text DEFAULT NULL,
  `newsBody` longtext DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `news`
--

INSERT INTO `news` (`id`, `important`, `newsTitle`, `newsBody`) VALUES
(1, 1, 'University Sports Registration Now Open', 'Calling all sports enthusiasts! Registration is officially open for our university\'s intramural sports leagues.'),
(2, 0, 'New Vollyball Courts Now Open for the Students', 'We\'re thrilled to announce the grand opening of our brand-new, world-class tennis courts, exclusively for out students.'),
(3, 0, 'Rajarata University Football Team Claims National Championship', 'Our beloved university\'s football team has clinched a triumphant victory in the national championship. Their remarkable talent and impeccable teamwork have made our nation and our university incredibly proud.');

-- --------------------------------------------------------

--
-- Table structure for table `players`
--

CREATE TABLE `players` (
  `PlayerID` int(11) NOT NULL,
  `Password` text NOT NULL,
  `FirstName` varchar(50) DEFAULT NULL,
  `LastName` varchar(50) DEFAULT NULL,
  `DateOfBirth` date DEFAULT NULL,
  `Gender` varchar(20) DEFAULT NULL,
  `Email` varchar(100) DEFAULT NULL,
  `PhoneNumber` varchar(20) DEFAULT NULL,
  `Address` text DEFAULT NULL,
  `EmergencyContactName` varchar(100) DEFAULT NULL,
  `EmergencyContactNumber` varchar(20) DEFAULT NULL,
  `MedicalConditions` text DEFAULT NULL,
  `RegistrationNo` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `players`
--

INSERT INTO `players` (`PlayerID`, `Password`, `FirstName`, `LastName`, `DateOfBirth`, `Gender`, `Email`, `PhoneNumber`, `Address`, `EmergencyContactName`, `EmergencyContactNumber`, `MedicalConditions`, `RegistrationNo`) VALUES
(2, '1234', 'Sachini', 'Fernando', '2003-06-20', 'Female', 'sachini.fernando@email.com', '777-vgt', '22 Kandy Road, Kandy, Sri Lanka', 'Nalini Fernando', '777-888-8888', 'Allergies', 22222),
(7, '1234', 'Maleesha ', 'Dinurnga', '2023-10-13', 'Male', 'maleeshadmax@gmail.com', '5327356', 'hfdwgyfgw', 'ewwwqwqdw', '646436435235', 'r223rrrrrrrr', 1007),
(8, '1122', 'sadfaada', 'adaa', '2023-11-13', 'Male', 'ff@ff.b', 'w4t', 'wt4', 'ssfdas', 'adad', 'ada', 9),
(9, '', '', '', '0000-00-00', '', '', '', '', '', '', '', 0);

-- --------------------------------------------------------

--
-- Table structure for table `player_sports`
--

CREATE TABLE `player_sports` (
  `ID` int(11) NOT NULL,
  `PlayerID` int(11) NOT NULL,
  `SportID` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `player_sports`
--

INSERT INTO `player_sports` (`ID`, `PlayerID`, `SportID`) VALUES
(8, 7, 101),
(9, 7, 102),
(10, 7, 103),
(11, 8, 104);

-- --------------------------------------------------------

--
-- Table structure for table `practices_schedule`
--

CREATE TABLE `practices_schedule` (
  `PracticeID` int(11) NOT NULL,
  `SportID` int(11) DEFAULT NULL,
  `CoachID` int(11) DEFAULT NULL,
  `PracticeDate` date DEFAULT NULL,
  `StartTime` time DEFAULT NULL,
  `EndTime` time DEFAULT NULL,
  `Location` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `practices_schedule`
--

INSERT INTO `practices_schedule` (`PracticeID`, `SportID`, `CoachID`, `PracticeDate`, `StartTime`, `EndTime`, `Location`) VALUES
(16, 101, 201, '2023-11-15', '09:00:00', '11:00:00', 'Play Ground'),
(19, 104, 201, '2023-11-10', '15:45:00', '16:45:00', 'Basketball Court'),
(20, 104, 201, '2023-11-10', '15:45:00', '16:45:00', 'Basketball Court'),
(21, 104, 201, '2023-11-10', '15:45:00', '16:45:00', 'Basketball Court');

-- --------------------------------------------------------

--
-- Table structure for table `sports`
--

CREATE TABLE `sports` (
  `SportID` int(11) NOT NULL,
  `SportName` varchar(100) NOT NULL,
  `Description` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `sports`
--

INSERT INTO `sports` (`SportID`, `SportName`, `Description`) VALUES
(101, 'Cricekt', NULL),
(102, 'Tennis', NULL),
(103, 'Soccer', NULL),
(104, 'Basketball', NULL),
(105, 'Badminton', NULL),
(106, 'Athletics', NULL),
(107, 'Volleyball', NULL),
(108, 'Swimming', NULL),
(109, 'Rugby', NULL),
(110, 'Table Tennis', NULL);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admins`
--
ALTER TABLE `admins`
  ADD PRIMARY KEY (`AdminID`),
  ADD UNIQUE KEY `Username` (`Username`),
  ADD UNIQUE KEY `Email` (`Email`);

--
-- Indexes for table `coaches`
--
ALTER TABLE `coaches`
  ADD PRIMARY KEY (`CoachID`),
  ADD KEY `SportID` (`SportID`);

--
-- Indexes for table `coach_sports`
--
ALTER TABLE `coach_sports`
  ADD PRIMARY KEY (`CoachSportID`),
  ADD KEY `CoachID` (`CoachID`),
  ADD KEY `SportID` (`SportID`);

--
-- Indexes for table `inventory`
--
ALTER TABLE `inventory`
  ADD PRIMARY KEY (`EquipmentID`);

--
-- Indexes for table `matches`
--
ALTER TABLE `matches`
  ADD PRIMARY KEY (`MatchID`),
  ADD KEY `SportID` (`SportID`);

--
-- Indexes for table `news`
--
ALTER TABLE `news`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `players`
--
ALTER TABLE `players`
  ADD PRIMARY KEY (`PlayerID`);

--
-- Indexes for table `player_sports`
--
ALTER TABLE `player_sports`
  ADD PRIMARY KEY (`ID`),
  ADD KEY `PlayerID` (`PlayerID`),
  ADD KEY `SportID` (`SportID`);

--
-- Indexes for table `practices_schedule`
--
ALTER TABLE `practices_schedule`
  ADD PRIMARY KEY (`PracticeID`),
  ADD KEY `SportID` (`SportID`),
  ADD KEY `CoachID` (`CoachID`);

--
-- Indexes for table `sports`
--
ALTER TABLE `sports`
  ADD PRIMARY KEY (`SportID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admins`
--
ALTER TABLE `admins`
  MODIFY `AdminID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `coaches`
--
ALTER TABLE `coaches`
  MODIFY `CoachID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=213;

--
-- AUTO_INCREMENT for table `coach_sports`
--
ALTER TABLE `coach_sports`
  MODIFY `CoachSportID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `inventory`
--
ALTER TABLE `inventory`
  MODIFY `EquipmentID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=51;

--
-- AUTO_INCREMENT for table `matches`
--
ALTER TABLE `matches`
  MODIFY `MatchID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=1009;

--
-- AUTO_INCREMENT for table `news`
--
ALTER TABLE `news`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=53;

--
-- AUTO_INCREMENT for table `players`
--
ALTER TABLE `players`
  MODIFY `PlayerID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `player_sports`
--
ALTER TABLE `player_sports`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `practices_schedule`
--
ALTER TABLE `practices_schedule`
  MODIFY `PracticeID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22;

--
-- AUTO_INCREMENT for table `sports`
--
ALTER TABLE `sports`
  MODIFY `SportID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=111;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `coaches`
--
ALTER TABLE `coaches`
  ADD CONSTRAINT `coaches_ibfk_1` FOREIGN KEY (`SportID`) REFERENCES `sports` (`SportID`);

--
-- Constraints for table `coach_sports`
--
ALTER TABLE `coach_sports`
  ADD CONSTRAINT `coach_sports_ibfk_2` FOREIGN KEY (`SportID`) REFERENCES `sports` (`SportID`);

--
-- Constraints for table `matches`
--
ALTER TABLE `matches`
  ADD CONSTRAINT `matches_ibfk_1` FOREIGN KEY (`SportID`) REFERENCES `sports` (`SportID`);

--
-- Constraints for table `player_sports`
--
ALTER TABLE `player_sports`
  ADD CONSTRAINT `player_sports_ibfk_1` FOREIGN KEY (`PlayerID`) REFERENCES `players` (`PlayerID`),
  ADD CONSTRAINT `player_sports_ibfk_2` FOREIGN KEY (`SportID`) REFERENCES `sports` (`SportID`);

--
-- Constraints for table `practices_schedule`
--
ALTER TABLE `practices_schedule`
  ADD CONSTRAINT `practices_schedule_ibfk_1` FOREIGN KEY (`SportID`) REFERENCES `sports` (`SportID`),
  ADD CONSTRAINT `practices_schedule_ibfk_2` FOREIGN KEY (`CoachID`) REFERENCES `coaches` (`CoachID`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
