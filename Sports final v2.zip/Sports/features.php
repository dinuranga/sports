<!DOCTYPE html>
<html lang="en">

<head>
    <link rel="stylesheet" href="assets/css/features.css">
</head>

<body>


    <div class="feature-container">

        <a href="practices.php">
            <div class="feature-card">
                <h3>PRACTICES</h3>
            </div>
        </a>
        <a href="view_matches.php">
            <div class="feature-card">
                <h3>MATCHES</h3>
            </div>
        </a>
        <a href="notices.php">
            <div class="feature-card">
                <h3>NOTICES</h3>
            </div>
        </a>
        <a href="equipments.php">
            <div class="feature-card">
                <h3>EQUIPMENTS</h3>
            </div>
        </a>

    </div>


</body>

</html>